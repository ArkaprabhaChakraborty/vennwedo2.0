class Hex {
  constructor(q, r, s) {
    this.q = q;
    this.r = r;
    this.s = s;
  }
}

export default Hex;
