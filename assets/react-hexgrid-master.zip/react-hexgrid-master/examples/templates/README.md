This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

## Run the example

```shell
npm install && npm start
```

## What's inside

An example with all the different grid types.
