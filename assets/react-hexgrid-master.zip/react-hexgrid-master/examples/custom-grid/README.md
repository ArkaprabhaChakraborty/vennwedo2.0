This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

## Run the example

```shell
npm install && npm start
```

## What's inside

Customly constructed hexagon grid with custom SVG elements on top.
