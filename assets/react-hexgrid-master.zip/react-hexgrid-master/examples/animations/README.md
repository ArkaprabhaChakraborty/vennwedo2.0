This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

## Run the example

```shell
npm install && npm start
```

## What's inside

Couple of examples on how to use; CSS animations, SVG filters and wrapper components (e.g. react-transition-group) to provide animations for Hexagons.
